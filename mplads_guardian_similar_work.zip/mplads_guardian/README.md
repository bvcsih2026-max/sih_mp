# MPLADS Guardian — Similar Work / Duplicate Detection Module

SIH 2026 · Problem Statement SIH26102

Scope of this module: **only** the similar-work / duplicate-detection
detector (`ml/detectors/similar_work.py`) and its tests. It is designed to
be imported into the existing MPLADS Guardian backend — it is not a
separate app or frontend.

## What it does

Given a list of MPLADS sanctioned works, it finds pairs that look highly
similar based on several **independent** pieces of evidence:

| Evidence               | Method                                                        |
|-------------------------|----------------------------------------------------------------|
| Work description        | TF-IDF + cosine similarity (default), or sentence-transformers embeddings (optional) |
| Work type                | exact match                                                    |
| District                 | exact match                                                    |
| Location                 | haversine distance in km (uses `geopy` if installed, else a built-in fallback) |
| Sanction amount           | percentage difference                                          |
| Sanction date              | day-difference, decayed over a configurable window            |

Each piece of evidence is scored 0–1 and combined into one weighted
`combined_score`, using only the evidence types that are actually
available for a given pair (weights re-normalize automatically). Pairs
above `combined_score_threshold` are emitted as signals.

**A signal is not a verdict.** The output explicitly states "Similar work
signal detected" and lists legitimate possible explanations (project
phases, work extensions, reused standard designs, duplicate reporting)
alongside recommended verification steps (work orders, BOQ, site
coordinates, completion documents).

## Install

Dependencies already used elsewhere in the project should cover this
module:

```bash
pip install pandas scikit-learn numpy
# optional, for embedding-based text similarity:
pip install sentence-transformers
# optional, for geodesic (vs. haversine) distance:
pip install geopy
```

Both optional packages are soft-imported — the module works without them
and just falls back to TF-IDF and haversine distance respectively.

## Usage

```python
from ml.detectors.similar_work import SimilarWorkDetector, SimilarWorkConfig

works = [
    {
        "work_id": "WORK-001",
        "description": "Construction of community hall at Village X",
        "work_type": "Community Infrastructure",
        "district": "Alwar",
        "location": (27.5530, 76.6346),   # (lat, lon)
        "sanction_amount": 1000000,
        "sanction_date": "2024-01-15",
    },
    {
        "work_id": "WORK-002",
        "description": "Construction of community hall near Village X",
        "work_type": "Community Infrastructure",
        "district": "Alwar",
        "location": (27.5600, 76.6400),
        "sanction_amount": 1050000,
        "sanction_date": "2024-02-01",
    },
]

detector = SimilarWorkDetector()          # default thresholds
signals = detector.detect(works)          # list of signal dicts

# Custom thresholds:
detector = SimilarWorkDetector(SimilarWorkConfig(
    text_similarity_threshold=0.5,
    combined_score_threshold=0.6,
    use_sentence_transformers=True,       # requires sentence-transformers
))
```

Only `work_id` and `description` are required for a work to be usable;
all other fields are optional and simply drop out of the combined score
(with weights renormalized) if missing.

## Signal schema (common schema)

```json
{
  "signal_id": "SIG-00001",
  "schema_version": "1.0",
  "work_id": "WORK-001",
  "detector_type": "similar_work",
  "priority": "HIGH",
  "anomaly_score": 81.54,
  "title": "Similar work signal detected",
  "observed_evidence": {
    "text_similarity": 0.6683,
    "same_district": true,
    "same_work_type": true,
    "location_distance_km": 0.943,
    "amount_difference_percent": 4.76,
    "date_difference_days": 17
  },
  "baseline": { "...": "thresholds used, compared_work_id" },
  "explanation": "Similar work signal detected. ...",
  "possible_explanation": [ "..." ],
  "recommended_verification": [ "..." ],
  "status": "NEW",
  "source": { "...": "detector, compared_work_ids, generated_at" },
  "metadata": { "text_similarity_method": "tfidf", "geopy_available": false }
}
```

## Configuration (`SimilarWorkConfig`)

All thresholds are configurable — nothing is hardcoded in the detection
logic:

- `text_similarity_threshold` (default 0.60) — minimum text similarity to consider
- `combined_score_threshold` (default 0.55) — minimum combined score to emit a signal
- `amount_diff_threshold_percent` (default 20.0) — normalization reference for amount scoring
- `date_proximity_days` (default 365) — window over which date proximity decays to 0
- `location_distance_km_threshold` (default 5.0) — window over which location proximity decays to 0
- `use_sentence_transformers` (default False) — switch text similarity to embeddings
- `weights` — per-evidence-type contribution to the combined score

## Files

```
ml/
  detectors/
    similar_work.py       — the detector
tests/
  test_similar_work.py    — unit tests (unittest, no external test runner required)
examples/
  example_input.json      — sample sanctioned-works dataset
  example_output.json     — signals produced by running the example
  run_example.py          — script that generates example_output.json
README.md
```

## Running tests

```bash
python -m unittest tests.test_similar_work -v
```

9/9 tests pass, covering: empty/singleton input, a clearly-similar pair,
unrelated works producing no signal, schema completeness, non-accusatory
language in `explanation`/`possible_explanation`, configurable thresholds,
graceful handling of missing optional fields, and score-descending sort
order.

## Running the example

```bash
python examples/run_example.py
```

This loads `examples/example_input.json` (5 sample works) and writes the
resulting signals to `examples/example_output.json`. With default
thresholds it emits 2 signals: WORK-001/WORK-002 (similar community
halls) and WORK-004/WORK-005 (similar water tanks); WORK-003 (unrelated
solar lighting work) produces no signal.
