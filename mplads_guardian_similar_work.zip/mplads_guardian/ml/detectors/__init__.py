from .similar_work import SimilarWorkDetector, SimilarWorkConfig

__all__ = ["SimilarWorkDetector", "SimilarWorkConfig"]
