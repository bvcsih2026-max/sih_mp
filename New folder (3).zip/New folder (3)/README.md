# MPLADS Guardian — AI Anomaly Detection Module

**Problem Statement:** SIH26102  
**Module Role:** Reusable AI Anomaly Detection Engine for Backend Integration

This Python module provides two independent detection systems for normalized MPLADS project records:

1. `financial_anomaly`: Uses scikit-learn's `IsolationForest` model alongside district, state, and work-type baseline medians to flag projects with abnormal financial patterns or cost per unit deviations.
2. `progress_mismatch`: Analyzes consistency between reported expenditure percentage and physical progress percentage, as well as logical project status anomalies (e.g. completed projects with 0% expenditure, very old projects still marked in progress).

---

## Directory Structure

```text
ml/
  __init__.py
  detectors/
    __init__.py
    financial_anomaly.py
    progress_anomaly.py

tests/
  test_financial_anomaly.py
  test_progress_anomaly.py

examples/
  sample_usage.py
```

---

## Input Requirements

The detector functions expect a normalized `pandas.DataFrame` containing MPLADS project records.

### Expected DataFrame Fields

| Field Name | Type | Description |
| :--- | :--- | :--- |
| `work_id` | `str` | Unique project work identifier |
| `sanction_amount` | `float` | Total sanctioned amount in INR |
| `expenditure_amount` | `float` | Cumulative expenditure to date |
| `district` | `str` | District name |
| `state` | `str` | State / UT name |
| `work_type` | `str` | Type of work (e.g. Road, Bridge, School, Water) |
| `physical_progress_percentage` | `float` | Physical progress (0 to 100) |
| `project_status` | `str` | Status (`In Progress`, `Completed`, etc.) |
| `start_date` / `sanction_date` | `str` | Project commencement or sanction date |
| `cost_per_unit` | `float` (optional) | Cost per unit if applicable |

---

## Shared Signal Output Schema

Every detector produces signal objects adhering strictly to the shared alert schema:

```json
{
  "signal_id": "SIG-00001",
  "schema_version": "1.0",
  "work_id": "WORK-001",
  "detector_type": "financial_anomaly",
  "priority": "HIGH",
  "anomaly_score": 82,
  "title": "Unusual financial pattern",
  "observed_evidence": {
    "sanction_amount": 1000000.0,
    "expenditure_amount": 900000.0,
    "expenditure_percentage": 90.0,
    "district": "District A",
    "state": "State A",
    "work_type": "Road"
  },
  "baseline": {
    "district_median_expenditure_percentage": 45.0,
    "state_median_expenditure_percentage": 45.0,
    "work_type_median_expenditure_percentage": 46.0,
    "comparison_basis": {
      "district_median": 45.0,
      "state_median": 45.0,
      "work_type_median": 46.0,
      "expenditure_percentage": 90.0
    }
  },
  "explanation": "Reported expenditure is unusually high or low relative to comparable projects in the same district, state, and work type.",
  "possible_explanation": [
    "reporting delay",
    "procurement/payment timing",
    "scope variation",
    "local price escalation"
  ],
  "recommended_verification": [
    "BOQ comparison",
    "payment records",
    "measurement records",
    "site verification"
  ],
  "status": "NEW",
  "source": {
    "method": "IsolationForest",
    "feature_set": ["expenditure_percentage", "district_delta", "state_delta", "work_type_delta"]
  },
  "metadata": {
    "expenditure_vs_district_median": 45.0,
    "expenditure_vs_state_median": 45.0,
    "expenditure_vs_work_type_median": 44.0
  }
}
```

---

## Detector Types & Priorities

### Detector Names
- `financial_anomaly`
- `progress_mismatch`

### Priority Mapping

| Anomaly Score Range | Priority | Meaning |
| :--- | :--- | :--- |
| `0 – 29` | `LOW` | Minor deviation / expected variation |
| `30 – 59` | `MEDIUM` | Moderate anomaly warranting standard review |
| `60 – 79` | `HIGH` | Strong signal requiring administrative audit |
| `80 – 100` | `CRITICAL` | Severe logical or statistical anomaly needing priority field verification |

---

## Important Legal & Product Rules

- `anomaly_score` represents **signal strength / degree of deviation**, NOT fraud probability.
- Never output phrases like `"This project is fraudulent"` or `"Fraud probability is 95%"`.
- All signal outputs use objective, investigation-supporting language: `"Anomalous pattern detected"`, `"Human verification recommended"`.

---

## Quickstart & How to Run

### Installation
```bash
python -m pip install pandas numpy scikit-learn pytest
```

### Running Unit Tests
```bash
python -m pytest -v
```

### Running Example Usage
```bash
python examples/sample_usage.py
```
