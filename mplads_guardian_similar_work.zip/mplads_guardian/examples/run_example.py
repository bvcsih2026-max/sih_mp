"""
Demo script: runs SimilarWorkDetector over examples/example_input.json
and writes the resulting signals to examples/example_output.json.

Usage:
    python examples/run_example.py
"""

import json
import os
import sys

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from ml.detectors.similar_work import SimilarWorkDetector

HERE = os.path.dirname(__file__)
INPUT_PATH = os.path.join(HERE, "example_input.json")
OUTPUT_PATH = os.path.join(HERE, "example_output.json")


def main():
    with open(INPUT_PATH) as f:
        works = json.load(f)

    detector = SimilarWorkDetector()  # default thresholds
    signals = detector.detect(works)

    with open(OUTPUT_PATH, "w") as f:
        json.dump(signals, f, indent=2)

    print(f"Loaded {len(works)} works, generated {len(signals)} signal(s).")
    print(f"Written to {OUTPUT_PATH}")


if __name__ == "__main__":
    main()
