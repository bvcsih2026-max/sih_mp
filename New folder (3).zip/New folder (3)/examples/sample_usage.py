import json
import os
import sys
import pandas as pd

# Ensure root directory is in sys.path when running script directly
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from ml.detectors.financial_anomaly import detect_financial_anomalies
from ml.detectors.progress_anomaly import detect_progress_anomalies


records = [
    {
        "work_id": "WORK-001",
        "sanction_amount": 1000000,
        "expenditure_amount": 900000,
        "district": "District A",
        "state": "State A",
        "work_type": "Road",
        "physical_progress_percentage": 34,
        "project_status": "In Progress",
        "start_date": "2024-01-01",
    },
    {
        "work_id": "WORK-002",
        "sanction_amount": 800000,
        "expenditure_amount": 0,
        "district": "District A",
        "state": "State A",
        "work_type": "Road",
        "physical_progress_percentage": 100,
        "project_status": "Completed",
        "start_date": "2023-06-01",
    },
    {
        "work_id": "WORK-003",
        "sanction_amount": 1200000,
        "expenditure_amount": 500000,
        "district": "District A",
        "state": "State A",
        "work_type": "Road",
        "physical_progress_percentage": 42,
        "project_status": "In Progress",
        "start_date": "2024-03-01",
    },
    {
        "work_id": "WORK-004",
        "sanction_amount": 1500000,
        "expenditure_amount": 1450000,
        "district": "District B",
        "state": "State A",
        "work_type": "Community Hall",
        "physical_progress_percentage": 20,
        "project_status": "In Progress",
        "start_date": "2020-01-01",
    },
]

df = pd.DataFrame(records)

print("=== Financial Anomaly Signals ===")
financial_signals = detect_financial_anomalies(df)
print(json.dumps(financial_signals, indent=2))

print("\n=== Progress Mismatch Signals ===")
progress_signals = detect_progress_anomalies(df)
print(json.dumps(progress_signals, indent=2))
